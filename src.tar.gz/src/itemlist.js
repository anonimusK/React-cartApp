import React, { Component } from 'react';
import './itemList.css';


class ItemList extends Component {
    state={
        counter:0,
        price:this.props.originalPrice,
        itemTotalPrice:0,
    };

    render() {
        return (
            <div className="itemList">
                <p>{this.props.itemName}</p>
                <p>{this.state.counter}</p>
                <p>{this.state.price}</p>
                <span onClick={this.decrement}>-</span>
                <span onClick={this.increment}>+</span>
                <span className='colorChange' onClick={this.delete}>x</span>
            </div>
        );
    }
    increment=()=>{
        this.state.itemTotalPrice+=this.props.originalPrice;
        this.props.totalPriceHandlerIncrement(this.props.originalPrice);
        this.setState({
         counter:(this.state.counter+1)
     })

    };
    decrement=()=>{
        this.state.itemTotalPrice-=this.props.originalPrice;
        this.props.totalPriceHandlerDecrement(this.props.originalPrice);
        this.setState({ counter:(this.state.counter-1)})

    };
    delete=()=>{
        this.props.deleteHandler(this.props.itemObject,this.state.itemTotalPrice);
    };
}

export default ItemList;
