import React, { Component } from 'react';
import './form.css';
import ItemList from './itemlist'

class Form extends Component {

    state={
        itemNames:{},
        triggerItemName: false,
        itemName:'',
        counter:0,
        totalPrice:0
    };

    formSubmitHandler=(event)=>{
        event.preventDefault();
        if(this.state.itemName.includes('-')) {
            this.state.counter+=1;
            let res = this.state.itemName.split('');
            let p=(this.state.itemName.match(/\d+/g).map(n => parseInt(n)));
            this.state.itemName=res.filter(word => (word!=='-') && isNaN(word));
            this.state.itemNames['itemName'+this.state.counter]={name:this.state.itemName,price:p};
            this.setState({});
        }
        else alert('Please enter price separated by a hyphen');
    };
    inputHandler=(event)=>{

        this.setState({
            [event.target.name]:event.target.value
        })
    };

    render() {
        return <div>
            <form onSubmit={this.formSubmitHandler}>
                <input name={'itemName'} onChange={this.inputHandler} className="form" type='text' placeholder={'Enter item and price separated by a - (hyphen)'} required/>
            </form>
            {this.state.itemNames && Object.keys(this.state.itemNames).map(function(item, id) {
                return <ItemList key={id} itemObject={this.state.itemNames[item]} deleteHandler={this.deleteHandler} totalPriceHandlerDecrement={this.totalPriceHandlerDecrement} totalPriceHandlerIncrement={this.totalPriceHandlerIncrement} itemName={this.state.itemNames[item].name} originalPrice={parseInt(this.state.itemNames[item].price)}/>;
            }.bind(this))}
            <div className='footer'>
                <label>TOTAL</label>
                <label className='floatright'>{this.state.totalPrice}</label>
            </div>
        </div>;
    }
    totalPriceHandlerIncrement=(data)=>{
        this.setState({
            totalPrice:(this.state.totalPrice+data)
        });
    };
    totalPriceHandlerDecrement=(data)=>{
        this.setState({
            totalPrice:(this.state.totalPrice-data)
        });
    };
    deleteHandler=(data1,data2)=>{

        {this.state.itemNames && Object.keys(this.state.itemNames).map(function(item, id) {
           if(this.state.itemNames[item]===data1){
               delete this.state.itemNames[item];
           }
        }.bind(this))}
        this.state.totalPrice-=data2;
        this.setState({});

    };
}

export default Form;
